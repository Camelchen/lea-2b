// This program has literals and a variable.

public class Literals
{
   public static void main(String[] args)
   {
      int apples;

      apples = 20;
      System.out.println("Today we sold " + apples +
                         " bushels of apples.");
   }
}
