// This is another simple Java program.

public class GreatFun
{
     public static void main(String[] args)
     {
          System.out.print("Programming is ");
          System.out.println("great fun!");
     }
}

