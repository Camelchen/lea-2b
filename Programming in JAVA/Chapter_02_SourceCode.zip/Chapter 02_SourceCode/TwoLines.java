// This is another simple Java program.

public class TwoLines
{
     public static void main(String[] args)
     {
          System.out.println("Programming is great fun!");
          System.out.println("I can't get enough of it!");
     }
}

